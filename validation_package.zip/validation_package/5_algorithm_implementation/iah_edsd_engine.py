#!/usr/bin/env python3
"""
Industrial Adaptive Hybrid Event-Driven Spoofing Detection (IAH-EDSD) Core Engine.
Implements event-driven monitoring, dynamic weight adaptation, multi-factor trust evaluation,
Early Warning Score (EWS), and cooperative cluster decision rules.
"""

import math
import numpy as np
from collections import defaultdict, deque

class IAHEDSDDetectionEngine:
    def __init__(self, node_id, pos, initial_energy=50.0):
        self.node_id = node_id
        self.pos = pos
        self.initial_energy = initial_energy
        
        self.known_positions = {}
        self.node_seq_tracker = defaultdict(int)
        self.node_rssi_history = defaultdict(list)
        self.node_rate_tracker = defaultdict(lambda: deque(maxlen=20))
        
        # Trust components: T_auth, T_behavior, T_energy
        self.t_auth = defaultdict(lambda: 1.0)
        self.t_behavior = defaultdict(lambda: 1.0)
        self.t_energy = defaultdict(lambda: 1.0)
        self.unified_trust = defaultdict(lambda: 1.0)
        
        # Early Warning Score (EWS) tracking
        self.event_counts = defaultdict(int)
        self.suspicious_counts = defaultdict(int)
        self.ews_scores = defaultdict(float)
        
        self.blacklisted_nodes = set()

    def register_node_position(self, target_id, pos):
        """Registers physical position coordinates for spatial fingerprinting."""
        self.known_positions[target_id] = pos

    def check_event_trigger(self, packet_rate, rssi_dev, is_new_node):
        """
        Event-Driven Monitoring Trigger (Phase 2):
        Triggers detection ONLY when:
        1. Packet rate spike (> 12 pkts/sec)
        2. Spatial RSSI deviation (> 5.0 dBm)
        3. Unregistered node join event
        """
        if is_new_node or packet_rate > 12.0 or rssi_dev > 5.0:
            return True
        return False

    def get_adaptive_weights(self, packet_rate, energy_level_pct, rssi_dev):
        """
        Phase 3: Adaptive Weight Calculation based on industrial environment.
        Weights: alpha (auth), beta (behavior), gamma (energy)
        """
        if packet_rate > 15.0:
            # High Traffic Spike
            alpha, beta, gamma = 0.20, 0.50, 0.30
        elif energy_level_pct < 0.30:
            # Low Energy Level
            alpha, beta, gamma = 0.20, 0.30, 0.50
        elif rssi_dev > 6.0:
            # High Industrial Interference / Spoofing Anomaly
            alpha, beta, gamma = 0.30, 0.50, 0.20
        else:
            # Normal Industrial Condition
            alpha, beta, gamma = 0.34, 0.33, 0.33
        return alpha, beta, gamma

    def calculate_rssi_deviation(self, claimed_id, current_rssi):
        """Phase 4: Physical RSSI Deviation from baseline spatial model."""
        expected_pos = self.known_positions.get(claimed_id)
        if not expected_pos:
            return 8.0  # High default deviation for unmapped node
        
        dx = expected_pos.x - self.pos.x
        dy = expected_pos.y - self.pos.y
        dz = expected_pos.z - self.pos.z
        dist = math.sqrt(dx*dx + dy*dy + dz*dz)
        if dist < 1.0:
            dist = 1.0
        
        # Log-Distance Path Loss Model (n = 2.7)
        exp_rssi = 0.0 - (10.0 * 2.7 * math.log10(dist))
        rssi_dev = abs(current_rssi - exp_rssi)
        return rssi_dev

    def update_early_warning_score(self, claimed_id, is_suspicious):
        """Phase 5: Early Warning Score (EWS) = Suspicious Events / Total Events."""
        self.event_counts[claimed_id] += 1
        if is_suspicious:
            self.suspicious_counts[claimed_id] += 1
        
        total = self.event_counts[claimed_id]
        suspicious = self.suspicious_counts[claimed_id]
        ews = float(suspicious) / float(total) if total > 0 else 0.0
        self.ews_scores[claimed_id] = ews
        return ews

    def evaluate_packet(self, claimed_id, current_rssi, seq_num, timestamp, is_signed, sig_valid, remaining_energy_joules):
        """
        Full Integrated IAH-EDSD Evaluation Pipeline:
        Combines Event Triggering, Adaptive Trust Calculation, EWS, and Final Detection.
        """
        # Calculate RSSI deviation
        rssi_dev = self.calculate_rssi_deviation(claimed_id, current_rssi)
        
        # Packet Rate Calculation
        rate_queue = self.node_rate_tracker[claimed_id]
        rate_queue.append(timestamp)
        pkt_rate = 1.0
        if len(rate_queue) > 1:
            time_span = rate_queue[-1] - rate_queue[0]
            if time_span > 0:
                pkt_rate = len(rate_queue) / time_span

        # Phase 2: Check Event Trigger
        is_new_node = 1 if claimed_id not in self.known_positions else 0
        trigger = self.check_event_trigger(pkt_rate, rssi_dev, is_new_node)

        # Base evaluation energy costs
        eval_energy = 0.000005  # Tier 1 physical screening (5 uJ)
        
        if not trigger:
            # Event-Driven Bypassing: Skip heavy trust & crypto computations when traffic is normal
            trust = self.unified_trust[claimed_id]
            ews = self.ews_scores[claimed_id]
            return 0, trust, ews, rssi_dev, False, eval_energy

        # Event Triggered: Execute Phase 3 Multi-Factor Trust & Adaptive Weights
        eval_energy += 0.000100  # Tier 2 ML evaluation (100 uJ)

        # 1. T_auth (Authentication Trust)
        if is_signed:
            if sig_valid:
                self.t_auth[claimed_id] = min(1.0, self.t_auth[claimed_id] + 0.1)
            else:
                self.t_auth[claimed_id] = max(0.0, self.t_auth[claimed_id] - 0.5)
        else:
            # Unsigned packet under triggered state
            self.t_auth[claimed_id] = 0.5

        # 2. T_behavior (Behavioral Trust: RSSI variance & sequence jumps)
        self.node_rssi_history[claimed_id].append(current_rssi)
        if len(self.node_rssi_history[claimed_id]) > 10:
            self.node_rssi_history[claimed_id].pop(0)
        rssi_var = np.var(self.node_rssi_history[claimed_id]) if len(self.node_rssi_history[claimed_id]) > 1 else 0.0

        last_seq = self.node_seq_tracker[claimed_id]
        seq_jump = abs(seq_num - last_seq) if last_seq > 0 else 0
        self.node_seq_tracker[claimed_id] = max(last_seq, seq_num)

        beh_penalty = (0.5 * (1 if rssi_dev > 5.0 else 0)) + (0.3 * (1 if seq_jump > 3 else 0)) + (0.2 * (1 if rssi_var > 3.0 else 0))
        self.t_behavior[claimed_id] = max(0.0, 1.0 - beh_penalty)

        # 3. T_energy (Energy Trust)
        energy_pct = max(0.0, remaining_energy_joules / self.initial_energy)
        self.t_energy[claimed_id] = energy_pct

        # Adaptive Weights
        alpha, beta, gamma = self.get_adaptive_weights(pkt_rate, energy_pct, rssi_dev)
        
        # Unified Trust Calculation
        trust = (alpha * self.t_auth[claimed_id]) + (beta * self.t_behavior[claimed_id]) + (gamma * self.t_energy[claimed_id])
        self.unified_trust[claimed_id] = trust

        # Phase 5: Update Early Warning Score
        is_suspicious = (trust < 0.6) or (rssi_dev > 5.0) or (seq_jump > 3)
        ews = self.update_early_warning_score(claimed_id, is_suspicious)

        # Selective Tier 3 Crypto Audit Trigger
        crypto_audited = False
        if trust < 0.6:
            crypto_audited = True
            eval_energy += 0.090  # 90 mJ ECDSA verification tax

        # Phase 7: Final Detection Rule
        # Spoofed if: (T < T_th) AND (EWS > E_th) AND (RSSI_dev > R_th)
        T_th, E_th, R_th = 0.60, 0.40, 5.0
        final_spoofed_verdict = 1 if (trust < T_th and ews > E_th and rssi_dev > R_th) else 0

        if final_spoofed_verdict == 1:
            self.blacklisted_nodes.add(claimed_id)

        return final_spoofed_verdict, trust, ews, rssi_dev, crypto_audited, eval_energy
